package com.idnkaltim.app

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var refresh: SwipeRefreshLayout

    private val base = "https://idnkaltim.com/"

    private val categories = linkedMapOf(
        "Berita Lokal" to "https://idnkaltim.com/category/berita-lokal/",
        "Kalimantan Timur" to "https://idnkaltim.com/category/kalimantan-timur/",
        "Kutai Kartanegara" to "https://idnkaltim.com/category/kutai-kartanegara/",
        "Politik" to "https://idnkaltim.com/category/politik/",
        "Kriminal" to "https://idnkaltim.com/category/kriminal/",
        "Bisnis" to "https://idnkaltim.com/category/bisnis/",
        "Otomotif" to "https://idnkaltim.com/category/otomotif/",
        "Kesehatan" to "https://idnkaltim.com/category/informasi-kesehatan/"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        buildUi()
        setupWebView()

        if (savedInstanceState == null) {
            web.loadUrl(base)
        }

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (web.canGoBack()) {
                        web.goBack()
                    } else {
                        finish()
                    }
                }
            }
        )
    }

    private fun buildUi() {

        // ROOT
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF7F7F7.toInt())
        }

        // HEADER
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp())
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        // LOGO
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.idnkaltim_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }

        header.addView(
            logo,
            LinearLayout.LayoutParams(
                0,
                54.dp(),
                1f
            )
        )

        // SEARCH BUTTON
        val search = MaterialButton(this).apply {
            text = "🔍"
            minWidth = 52.dp()
            setOnClickListener {
                showSearch()
            }
        }

        header.addView(
            search,
            LinearLayout.LayoutParams(
                58.dp(),
                54.dp()
            )
        )

        root.addView(
            header,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                70.dp()
            )
        )

        // REFRESH + WEBVIEW
        refresh = SwipeRefreshLayout(this)

        web = WebView(this)

        refresh.addView(
            web,
            SwipeRefreshLayout.LayoutParams(
                SwipeRefreshLayout.LayoutParams.MATCH_PARENT,
                SwipeRefreshLayout.LayoutParams.MATCH_PARENT
            )
        )

        refresh.setOnRefreshListener {
            web.reload()
        }

        root.addView(
            refresh,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        // BOTTOM NAVIGATION
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        fun navButton(
            text: String,
            action: () -> Unit
        ): Button {
            return Button(this).apply {
                this.text = text
                isAllCaps = false

                setOnClickListener {
                    action()
                }
            }
        }

        nav.addView(
            navButton("Beranda") {
                web.loadUrl(base)
            },
            LinearLayout.LayoutParams(
                0,
                62.dp(),
                1f
            )
        )

        nav.addView(
            navButton("Kategori") {
                showCategories()
            },
            LinearLayout.LayoutParams(
                0,
                62.dp(),
                1f
            )
        )

        nav.addView(
            navButton("Bagikan") {
                share()
            },
            LinearLayout.LayoutParams(
                0,
                62.dp(),
                1f
            )
        )

        root.addView(nav)

        setContentView(root)
    }

    private fun setupWebView() {

        web.settings.apply {

            javaScriptEnabled = true

            domStorageEnabled = true

            loadsImagesAutomatically = true

            mediaPlaybackRequiresUserGesture = true

            mixedContentMode =
                WebSettings.MIXED_CONTENT_NEVER_ALLOW

            userAgentString =
                "$userAgentString IDNKaltimApp/5.0"
        }

        web.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {

                val url = request.url.toString()

                return if (
                    url.startsWith("https://idnkaltim.com") ||
                    url.startsWith("http://idnkaltim.com")
                ) {

                    false

                } else {

                    try {
                        startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                request.url
                            )
                        )
                    } catch (_: Exception) {
                        // Tidak ada aplikasi yang bisa membuka URL
                    }

                    true
                }
            }

            override fun onPageFinished(
                view: WebView,
                url: String
            ) {
                refresh.isRefreshing = false
            }
        }
    }

    private fun showCategories() {

        val items = categories.keys.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Kategori IDNKaltim")
            .setItems(items) { _, which ->

                val selectedUrl = categories[items[which]]

                if (selectedUrl != null) {
                    web.loadUrl(selectedUrl)
                }
            }
            .show()
    }

    private fun showSearch() {

        val input = EditText(this).apply {
            hint = "Contoh: Balikpapan"
            setSingleLine(true)
        }

        AlertDialog.Builder(this)
            .setTitle("Cari berita")
            .setView(input)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Cari") { _, _ ->

                val keyword = input.text.toString().trim()

                if (keyword.isNotEmpty()) {

                    val searchUrl =
                        "https://idnkaltim.com/?s=${Uri.encode(keyword)}"

                    web.loadUrl(searchUrl)
                }
            }
            .show()
    }

    private fun share() {

        val url = web.url ?: base

        val intent = Intent(Intent.ACTION_SEND).apply {

            type = "text/plain"

            putExtra(
                Intent.EXTRA_TEXT,
                url
            )
        }

        startActivity(
            Intent.createChooser(
                intent,
                "Bagikan IDNKaltim"
            )
        )
    }

    private fun Int.dp(): Int {
        return (
            this * resources.displayMetrics.density
        ).toInt()
    }
}