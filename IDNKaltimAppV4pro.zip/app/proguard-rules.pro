# IDNKaltim release rules
