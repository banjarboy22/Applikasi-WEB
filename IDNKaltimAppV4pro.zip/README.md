# IDNKaltimApp V4 — build on Android phone

Versi ini dibuat lebih ringan untuk AndroidIDE: Kotlin + AndroidX + Material, tanpa Picasso atau library tambahan yang tidak diperlukan.

## Build di HP
1. Ekstrak ZIP.
2. Buka folder yang berisi `settings.gradle` di AndroidIDE.
3. Pastikan JDK 17 tersedia.
4. Tunggu Gradle Sync.
5. Tekan Run/Build > Assemble Debug.
6. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Project memakai Android Gradle Plugin 8.1.4, compileSdk 34, minSdk 23.

Website: https://idnkaltim.com/
Package: com.idnkaltim.app
Version: 4.0
